package com.unimind.unithing.Data

data class MajorCERT(
    val string: String? = null
)