# Original Knowledge(OK)
 전공별 커뮤니티 앱
 
## 키워드
- MVP 패턴 & Repository 패턴
- Firebase Auth
- Firestore

## 와이어프레임-피그마
- https://www.figma.com/file/Z4ndiqsYfg9lsECWBC9b0x/OK?type=design&node-id=0%3A1&t=5CEQ2XLFKMw9iz0S-1